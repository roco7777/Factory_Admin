const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// --- CONFIGURA ESTO CON TUS DATOS REALES ---
const db = mysql.createPool({
  host: 'localhost',       // Si MariaDB está en esta misma PC
  user: 'root',            // TU USUARIO (usualmente es root)
  password: 'ADMIN'  , // TU CONTRASEÑA DE MARIADB
  database: 'factory' // EL NOMBRE EXACTO DE TU BASE DE DATOS
});
// -------------------------------------------
// --- NUEVA RUTA: /api/login (Método POST) ---
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  
  // Asumimos que la tabla de usuarios tiene las columnas 'usuario' y 'contraseña'
  // y 'rol' (administrador, supervisor, etc.)
  const query = 'SELECT nombre FROM usuarios WHERE nombre = ? AND password = ?'; 
  
  db.execute(query, [username, password], (err, results) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Error de servidor: falló la consulta.' });
    }
    
    if (results.length > 0) {
      // Éxito
      return res.status(200).json({ 
        success: true, 
        message: 'Acceso concedido.', 
        user: results[0].usuario, 
        rol: results[0].rol // Retornamos el rol
      });
    } else {
      // Fallo
      return res.status(401).json({ success: false, message: 'Usuario o contraseña incorrectos.' });
    }
  });
});
// ----------------------------------------------

// Ruta para buscar productos
app.get('/api/inventario', (req, res) => {
  const busqueda = req.query.busqueda;
  
  // Esta consulta une la tabla principal con las 5 tablas de almacén
  let query = `
    SELECT 
      p.Descripcion, 
      p.Clave, 
      p.Precio1,
      COALESCE(a1.ExisPVentas, 0) AS stock1,
      COALESCE(a2.ExisPVentas, 0) AS stock2,
      COALESCE(a3.ExisPVentas, 0) AS stock3,
      COALESCE(a4.ExisPVentas, 0) AS stock4,
      COALESCE(a5.ExisPVentas, 0) AS stock5
    FROM PRODUCTOS p
    LEFT JOIN alm1 a1 ON p.Clave = a1.Clave
    LEFT JOIN alm2 a2 ON p.Clave = a2.Clave
    LEFT JOIN alm3 a3 ON p.Clave = a3.Clave
    LEFT JOIN alm4 a4 ON p.Clave = a4.Clave
    LEFT JOIN alm5 a5 ON p.Clave = a5.Clave
  `;

  let params = [];

  if (busqueda) {
    // Usamos 'p.' para especificar que buscamos en la tabla principal
    query += ' WHERE p.Descripcion LIKE ? OR p.Clave LIKE ? OR p.CB LIKE ?'; 
    params.push(`%${busqueda}%`, `%${busqueda}%`, `%${busqueda}%`);
  }
  
  // Limitar a 50 resultados para que sea rápido
  query += ' LIMIT 50';

  db.execute(query, params, (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error en DB: ' + err.message);
    } else {
      console.log("--- Búsqueda de 5 Sucursales realizada ---");
      res.json(results);
    }
  });
});

// NUEVA RUTA para obtener los nombres de las sucursales
app.get('/api/sucursales', (req, res) => {
  // Solo solicitamos el ID y el Nombre de la tabla CatSuc
  const query = 'SELECT ID, sucursal FROM Empresa ORDER BY ID ASC';

  db.execute(query, (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error al buscar nombres de sucursales: ' + err.message);
    } else {
      res.json(results);
    }
  });
});

app.listen(3000, '127.0.0.1', () => {
  console.log('✅ Servidor listo en el puerto 3000');
});